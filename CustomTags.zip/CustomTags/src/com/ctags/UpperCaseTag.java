package com.ctags;

import java.io.IOException;
import java.io.StringWriter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class UpperCaseTag extends SimpleTagSupport {
	public void doTag() throws JspException,IOException
	{
	StringWriter sw=new StringWriter();
	getJspBody().invoke(sw);
	String bodyText=sw.toString();
	JspWriter out=getJspContext().getOut();
	out.print(bodyText.toUpperCase());
	}
	
}
