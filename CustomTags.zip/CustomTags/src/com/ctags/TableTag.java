package com.ctags;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class TableTag extends SimpleTagSupport {
private String[] headers;
private List<User> userList;
public String[] getHeaders() {
	return headers;
}
public void setHeaders(String[] headers) {
	this.headers = headers;
}
public List<User> getUserList() {
	return userList;
}
public void setUserList(List<User> userList) {
	this.userList = userList;
}
public void doTag() throws JspException,IOException
{
	JspWriter out=getJspContext().getOut();
	out.print("<table style='border :2px solid:red';>");
	out.print("<tr>");
	for(String header:headers)
	{
		out.print("<th style='border:1px solid blue;'>"+header+"</th>");
	}
	out.print("</tr>");
	for(User user:userList)
	{
		out.print("<tr>");
		out.print("<td>"+user.getName()+"</td>");
		out.print("<td>"+user.getEmail()+"</td>");
		out.print("<td>"+user.getPhone()+"</td>");
		out.print("</tr>");
	}
	
}
}
