package com.session;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Inbox
 */
@WebServlet("/Inbox2")
public class Inbox2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Inbox2() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		String username = null;
		String location = null;
		HttpSession session = request.getSession();
		if (session.getAttribute("user") == null) {
			response.sendRedirect("SLogin.html");
		} else {
			username = session.getAttribute("user").toString();
			location = session.getAttribute("location").toString();
		}
		System.out.println("Session is new ="+session.isNew());
		System.out.println("Session id ="+session.getId());
		PrintWriter out = response.getWriter();
		out.print("<html><head><title>Inbox</title></head><body>");
		out.print("<h1 style='margin-left:40%;'>Inbox</h1>");
		out.print("<h2> Welcome " + username + "</h2>");
		out.print("<h2> Location " + location + "</h2>");
		out.print("<a href='SentItems2'/>Sent Items</a>");
		out.print("<br>");
		out.print("<a href='LogOut'/>Log out</a>");
		out.print("</body></html>");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
