package com.session;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet2")
public class LoginServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet2() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = request.getParameter("username");
		String password = request.getParameter("pass");
		String location = request.getParameter("location");
		if ("admin".equals(username) && "admin@123".equalsIgnoreCase(password)) {
			HttpSession session = request.getSession();
			System.out.println("Session is new ="+session.isNew());
			System.out.println("Session id ="+session.getId());
			//session.setMaxInactiveInterval(interval);
			session.setAttribute("user", username);
			session.setAttribute("location", location);
			response.sendRedirect("Inbox2");
		}

	}

}
