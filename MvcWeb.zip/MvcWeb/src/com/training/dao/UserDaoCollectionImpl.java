package com.training.dao;

import java.util.ArrayList;
import java.util.List;

import com.training.bean.User;

public class UserDaoCollectionImpl implements UserDao {
	static List<User> usrList;
	public UserDaoCollectionImpl()
	{
		if(usrList==null)
		{
			usrList=new ArrayList<>();
			usrList.add(new User("Sai","s","sai@gmail.com","India","male") );
			usrList.add(new User("Minu","M","minu@gmail.com","India","female") );
		}
	}

	@Override
	public List<User> fetchUsers() {
		
		return usrList;
	}

}
