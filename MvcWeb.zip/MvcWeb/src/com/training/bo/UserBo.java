package com.training.bo;

import java.util.List;

import com.training.bean.User;
import com.training.dao.UserDao;
import com.training.dao.UserDaoCollectionImpl;

public class UserBo {

	public List<User> fetchUsers() {
		UserDao userDao=new UserDaoCollectionImpl();
		List<User> userList=userDao.fetchUsers();
		return userList;
	}

}
