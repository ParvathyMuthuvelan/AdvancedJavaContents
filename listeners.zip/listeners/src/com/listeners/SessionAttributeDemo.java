package com.listeners;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * Application Lifecycle Listener implementation class SessionAttributeDemo
 * 
 */
@WebListener
public class SessionAttributeDemo implements HttpSessionAttributeListener,HttpSessionListener {

	/**
	 * Default constructor.
	 */
	public SessionAttributeDemo() {
		// TODO Auto-generated constructor stub
	}
	 public void sessionCreated(HttpSessionEvent se)  { 
         System.out.println("Session is created "+se.getSession().getCreationTime());
    }

	/**
     * @see HttpSessionListener#sessionDestroyed(HttpSessionEvent)
     */
    public void sessionDestroyed(HttpSessionEvent se)  { 
        System.out.println("session destroying");
    }

	/**
	 * @see HttpSessionAttributeListener#attributeRemoved(HttpSessionBindingEvent)
	 */
	@Override
	public void attributeRemoved(HttpSessionBindingEvent arg0) {
		// TODO Auto-generated method stub
		System.out.println("Attribute " + arg0.getName() + "and value "
				+ arg0.getValue() + "is removed");
	}

	/**
	 * @see HttpSessionAttributeListener#attributeAdded(HttpSessionBindingEvent)
	 */
	@Override
	public void attributeAdded(HttpSessionBindingEvent arg0) {
		// TODO Auto-generated method stub
		System.out.println("Attribute " + arg0.getName() + "and value "
				+ arg0.getValue() + "is added");
	}

	/**
	 * @see HttpSessionAttributeListener#attributeReplaced(HttpSessionBindingEvent)
	 */
	@Override
	public void attributeReplaced(HttpSessionBindingEvent arg0) {
		// TODO Auto-generated method stub
		System.out.println("Attribute " + arg0.getName() + "and value "
				+ arg0.getValue() + "is replaced");
	}

}
